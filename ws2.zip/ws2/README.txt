Files included:
* source - source code of Java project
* program.exe - main program executable (Additional Java installation might be required, visit java.com/en/download/win10.jsp)
* members.json - the member list, already contains some data
* diagrams - contains diagrams of the program
	* design_model.png - Class diagram over the entire application (does not contain all attributes and methods)
	* sequence_diagram_in.png - Sequence diagram which covers one input requirement
	* sequence_diagram_out.png - Sequence diagram which covers one output requirement
