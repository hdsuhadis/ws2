package model;

import java.util.ArrayList;

public class BoatClubMember extends Member{
	private ArrayList<Boat> registeredBoats;

	// Constructor
	public BoatClubMember(String name, long personalNumber, String memberID) {
		super(name, personalNumber, memberID);
		this.registeredBoats = new ArrayList<Boat>();
	}
	
	// Add a new boat to the member's list of boats
	public void addBoat(Boat boat) {
		this.registeredBoats.add(boat);
	}
	
	// Override the current list of boats with a new list
	public void setBoatList(ArrayList<Boat> boatList) {
		this.registeredBoats = boatList;
	}
	
	// Return the current list of boats
	public ArrayList<Boat> getBoatList(){
		ArrayList<Boat> returnList = new ArrayList<Boat>();
		returnList.addAll(this.registeredBoats);
		
		return returnList;
	}

}
